<?php

namespace App\Models;

use CodeIgniter\Model;

class GaleriModel extends Model
{
    protected $table = 'galeri';
    protected $primaryKey = 'id_galeri';
    protected $useTimestamps = true;
    protected $allowedFields = ['title_galeri', 'gambar_galeri', 'desc_galeri'];

    public function getGaleri($id = false)
    {
        if($id == false) {
            return $this->findAll();
        }

        return $this->where(['id_galeri' => $id])->first();
    }
    // public function getTitle($title = false)
    // {
    //     if($title == false) {
    //         return $this->findAll();
    //     }

    //     return $this->where(['title_info' => $title])->first();
    // }
    
}