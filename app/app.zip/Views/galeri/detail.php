<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

.container

<?= $this->endSection(); ?>