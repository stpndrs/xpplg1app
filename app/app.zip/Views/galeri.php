<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="container galeri-page" id="home">
    <header>
        <div class="bg"></div>
        <h1 class="yellow">Galeri</h1>
    </header>

    <section>
        <div class="galeri" id="galeri">

            <div class="row">

                <?php foreach($galeri as $glr) : ?>
                <div class="col col-4 mb-4">
                    <div class="card">
                        <img src="/img/<?= $glr['gambar_galeri']; ?>" alt="">
                        <div class="content">
                            <h3 class="yellow"><?= $glr['title_galeri']; ?></h3>
                            <p class="blue"><?= $glr['updated_at']; ?></p>
                            <p><?= $glr['desc_galeri']; ?></p>
                            <!-- <a href="/galeri/detail" class="yellow">Selengkapnya....</a> -->
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>

            </div>

        </div>
    </section>

</div>

<?= $this->endSection(); ?>