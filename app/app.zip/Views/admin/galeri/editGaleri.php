<?= $this->extend('admin/layout/template'); ?>

<?= $this->section('content'); ?>

<div class="container" id="edit-galeri">

  <h1 class="yellow">Edit Galeri</h1>

  <form action="/admin/updateGaleri/<?= $glr['id_galeri']; ?>" method="POST" enctype="multipart/form-data">
    <?= csrf_field(); ?>
    <input type="hidden" name="txtId" value="<?= $glr['id_galeri']; ?>">
    <input type="hidden" name="txtGambarLama" value="<?= $glr['gambar_galeri']; ?>">
    <!-- <h5 class="blue">Title Berita</h5>
    <input type="text" name="txtTitle" placeholder="Title Berita...." class="<?= ($validation->hasError('txtTitle'))? 'is-invalid' : ''; ?>" value="<?= old('txtTitle'); ?>">
    <hr>
    <div id="validationServer03Feedback" class="invalid-feedback">
      <?= $validation->getError('txtTitle'); ?>
    </div> -->

    <h5 class="blue">Title Galeri</h5>
    <input type="text" name="txtTitle" placeholder="Title Galeri...." class="<?= ($validation->hasError('txtTitle'))? 'is-invalid' : ''; ?>" value="<?= (old('txtTitle')) ? old('txtTitle') : $glr['title_galeri'] ?>">
    <hr>
    <div id="validationServer03Feedback" class="invalid-feedback">
      <?= $validation->getError('txtTitle'); ?>
    </div>

    <br>
    <br>

    <h5 class="blue">Isi Galeri</h5>
    <textarea class="ckeditor ck-add-task <?= ($validation->hasError('txtIsi'))? 'is-invalid' : ''; ?>" id="ckeditor" name="txtIsi"><?= nl2br((old('txtIsi')) ? old('txtIsi') : $glr['desc_galeri']) ?></textarea>
    <hr>
    <div id="validationServer03Feedback" class="invalid-feedback">
      <?= $validation->getError('txtIsi'); ?>
    </div>

    <br>
    <br>

    <h5 class="blue">Upload Gambar</h5>
    <h6 class="form-label-gambar yellow"></h6>
    <input class="form-control <?= ($validation->hasError('txtGambar'))? 'is-invalid' : ''; ?>" type="file" id="gambar" name="txtGambar" value="<?= old('txtGambar'); ?>" onchange="previewGambar()">
    <br>
    <div class="col-sm-2">
      <img src="/img/no-image.png" class="img-thumbnail img-preview">
    </div>
    <div id="validationServer03Feedback" class="invalid-feedback">
      <?= $validation->getError('txtGambar'); ?>
    </div>

    <button type="submit" class="btn btn-primary" style="margin-left: 0;">Simpan</button>
    <p onclick="window.history.go(-1)" class="text-start btn blue"><i class="bi bi-chevron-double-left"></i>Kembali</p>

  </form>
</div>

<?= $this->endSection(); ?>