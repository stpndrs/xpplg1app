<?= $this->extend('admin/layout/template'); ?>

<?= $this->section('content'); ?>


<div class="container" id="jadwal">
    <header>
        <div class="bg"></div>
        <h1 class="title yellow">Jadwal Kelas</h1>
    </header>
    
    <section id="jadwal-video">
        <div class="row" id="jrow">
            <h4 class="blue">Jadwal Video Conference</h4>

            <?php foreach($jvideo as $jvc) : ?>
            <div class="col">
                <div class="card">
                    <h5 class="yellow"><?= $jvc['hari_jgmeet']; ?></h5>
                    <p class="blue">Seragam : <strong><?= $jvc['seragam_jgmeet']; ?></strong></p>
                    <p class="yellow"><strong><?= $jvc['mapel1_jgmeet']; ?></strong></p>
                    <p class="blue"><?= $jvc['nmguru1_jgmeet']; ?></p>
                    <p class="yellow"><strong><?= $jvc['mapel2_jgmeet']; ?></strong></p>
                    <p class="blue"><?= $jvc['nmguru2_jgmeet']; ?></p>
                    <p class="yellow"><strong><?= $jvc['mapel3_jgmeet']; ?></strong></p>
                    <p class="blue"><?= $jvc['nmguru3_jgmeet']; ?></p>
                    <p class="yellow"><strong><?= $jvc['mapel4_jgmeet']; ?></strong></p>
                    <p class="blue"><?= $jvc['nmguru4_jgmeet']; ?></p>

                    <a href="/admin/editJgmeet/<?= $jvc['id_jgmeet']; ?>">
                        <button class="btn" style="margin: 1vh 2vh 2vh 0;">edit</button>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>

        </div>
    </section>
    
    <section id="jadwal-penugasan">
        <div class="row" id="jrow">
            <h4 class="blue">Jadwal Pemberian Tugas</h4>

            <?php foreach($jtugas as $jpt) : ?>
            <div class="col">
                <div class="card">
                    <h5 class="yellow"><?= $jpt['hari_jtugas']; ?></h5>
                    <p class="yellow"><strong><?= $jpt['mapel1_jtugas']; ?></strong></p>
                    <p class="blue"><?= $jpt['nmguru1_jtugas']; ?></p>
                    <p class="yellow"><strong><?= $jpt['mapel2_jtugas']; ?></strong></p>
                    <p class="blue"><?= $jpt['nmguru2_jtugas']; ?></p>
                    <p class="yellow"><strong><?= $jpt['mapel3_jtugas']; ?></strong></p>
                    <p class="blue"><?= $jpt['nmguru3_jtugas']; ?></p>
                    <p class="yellow"><strong><?= $jpt['mapel4_jtugas']; ?></strong></p>
                    <p class="blue"><?= $jpt['nmguru4_jtugas']; ?></p>

                    <a href="/admin/editJtugas/<?= $jpt['id_jtugas']; ?>">
                        <button class="btn" style="margin: 1vh 2vh 2vh 0;">edit</button>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>

        </div>
    </section>

</div>






<?= $this->endSection(); ?>






