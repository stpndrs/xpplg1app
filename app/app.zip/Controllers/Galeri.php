<?php

namespace App\Controllers;

use App\Models\LayoutModel;
use App\Models\GaleriModel;

class Galeri extends BaseController
{
    protected $layoutModel;
    protected $galeriModel;
    protected $db;
    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->layoutModel = new LayoutModel();
        $this->galeriModel = new GaleriModel();
    }
    public function index()
    {
        $layout = $this->db->table('layout');
        $galeri = $this->db->table('galeri');
        $queryLayout = $layout->get()->getResultArray();
        $query = $galeri->get()->getResultArray();

        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Galeri',
            'galeri' => $query
        ];
        // return view('welcome_message');
        return view('galeri', $data);
    }
    public function detail()
    {
        $data = [
            'title' => 'Intelligence Class | Galeri | Detail'
        ];

        return view('detail', $data);
    }

    
}
