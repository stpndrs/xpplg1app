<?php

namespace App\Controllers;

use App\Models\BeritaModel;
use App\Models\LayoutModel;

class Berita extends BaseController
{
    protected $beritaModel;
    protected $layoutModel;
    protected $db;
    public function __construct()
    {
        $this->db = \Config\Database::connect();    
        $this->beritaModel = new BeritaModel();
        $this->layoutModel = new LayoutModel();
    }
    public function index()
    {
        $berita = $this->db->table('infosklh');
        $query = $berita->get()->getResultArray();
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Berita',
            'berita' => $query
        ];
        return view('berita', $data);
    }
    function download($id)
	{
		$berkas = new BeritaModel();
		$data = $berkas->find($id);
		return $this->response->download('file-info/' . $data->berkas, null);
	}
    public function detail($id)
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Berita | Berita - Detail',
            'dtl' => $this->beritaModel->getBerita($id)
        ];
        return view('berita/detail', $data);
    }

}
