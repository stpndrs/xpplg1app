<?php

namespace App\Controllers;

use App\Models\LayoutModel;
use App\Models\HomeModel;
use App\Models\BeritaModel;
use App\Models\GaleriModel;
use App\Models\JgmeetModel;
use App\Models\JtugasModel;
use App\Models\SiswaModel;

class Admin extends BaseController
{
    protected $db;
    protected $layoutModel;
    protected $homeModel;
    protected $beritaModel;
    protected $jgmeetModel;
    protected $jtugasModel;
    protected $galeriModel;
    protected $siswaModel;
    public function __construct()
    {
        $this->db = \Config\Database::connect();    
        $this->layoutModel = new LayoutModel();
        $this->homeModel = new HomeModel();
        $this->beritaModel = new BeritaModel();
        $this->galeriModel = new GaleriModel();
        $this->jgmeetModel = new JgmeetModel();    
        $this->jtugasModel = new JtugasModel(); 
        $this->siswaModel = new SiswaModel(); 
    }
    public function index()
    {
        $layout = $this->db->table('layout');
        $home = $this->db->table('home');
        $berita = $this->db->table('infosklh');
        $galeri = $this->db->table('galeri');
        $queryLayout = $layout->get()->getResultArray();
        $queryHome = $home->get()->getResultArray();
        $queryGaleri = $galeri->get(3)->getResultArray();
        $queryBerita = $berita->get(3)->getResultArray();
        $data = [
            'title' => 'Intelligence Class',
            'layout' => $queryLayout,
            'home' => $queryHome,
            'galeri' => $queryGaleri,
            'berita' => $queryBerita
        ];
        return view('admin/home/home', $data);
    }
    public function editHome($id)
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Edit Home Page',
            'validation' => \Config\Services::validation(),
            'he' => $this->homeModel->getHome($id)
        ];
        return view('admin/home/editHome', $data);
    }
    public function deleteHome($id)
    {
        $home = $this->homeModel->find($id);

        // cek gambar default
        if($home['carousel_home'] != 'no-image.png') {
            // hapus gambar
            unlink('img/' . $home['carousel_home']);
        }

        $this->homeModel->delete($id);
        session()->setFlashdata('pesan', 'Carousel Lama Telah Terhapus!');
        return redirect()->to('/admin');
    }

    // BERITA ~ BERITA
    public function berita()
    {
        $layout = $this->db->table('layout');
        $berita = $this->db->table('infosklh');
        $queryLayout = $layout->get()->getResultArray();
        $query = $berita->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Berita',
            'berita' => $query
        ];
        return view('admin/berita/berita', $data);
    }
    public function download()
    {
        return view('admin/berita/download');
    }
    public function detail($id)
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Berita | Berita - Detail',
            'dtl' => $this->beritaModel->getBerita($id)
        ];
        return view('admin/berita/detail', $data);
    }



    public function addBerita() 
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Tambah Berita',
            'validation' => \Config\Services::validation()
        ];
        return view('admin/berita/addBerita', $data);
    }
    public function saveBerita()
    {
        // ccek validasi input
        if(!$this->validate([
            'txtTitle' => [
                'rules' => 'required|is_unique[infosklh.title_info]',
                'errors' => [
                    'required' => 'Title Berita Tidak Boleh Kosong!',
                    'is_unique' => 'Title Berita Tidak Boleh Sama!'
                ]
            ],
            'txtLink' => [
                'rules' => 'is_unique[infosklh.link_info]',
                'errors' => [
                    // 'required' => 'Link Berita Tidak Boleh Kosong!',
                    'is_unique' => 'Link Berita Tidak Boleh Sama!'
                ]
            ],
            'txtIsi' => [
                'rules' => 'required|is_unique[infosklh.isi_info]',
                'errors' => [
                    'required' => 'Isi Berita Tidak Boleh Kosong!',
                    'is_unique' => 'Isi Berita Tidak Boleh Sama!'
                ]
            ],
            'txtGambar' => [
                'rules' => 'max_size[txtGambar,1600]|is_image[txtGambar]|mime_in[txtGambar,image/jpg,image/jpeg,image/png]',
                'errors' => [
                    'max_size' => 'Ukuran gambar terlalu besar',
                    'is_image' => 'Hanya Gambar Yang Diperbolehkan!',
                    'mime_in' => 'Hanya Gambar Yang Diperbolehkan!'
                ]
            ]
        ])) {
            return redirect()->to('/admin/berita/addBerita')->withInput();
        }
        
        // ambil gambar
        $fileGambar = $this->request->getFile('txtGambar');
        // cek ada gambar atau tidak
        if($fileGambar->getError() == 4) {
            $namaGambar = 'no-image.png';
        } else {
        // generate nama foto
        $namaGambar = $fileGambar->getRandomName();
        // pindah file
        $fileGambar->move('img', $namaGambar);
        }

        $this->beritaModel->save([
            'title_info' => $this->request->getVar('txtTitle'),
            'link_info' => $this->request->getVar('txtLink'),
            'isi_info' => $this->request->getVar('txtIsi'),
            'gambar_info' => $namaGambar
        ]);

        session()->setFlashdata('pesan', 'Berita Baru Telah Ditambahkan!');
        return redirect()->to('/admin/berita');
    }

    public function deleteBerita($id)
    {
        $this->beritaModel->delete($id);
        session()->setFlashdata('pesan', 'Berita Lama Telah Terhapus!');
        return redirect()->to('/admin/berita');
    }

    public function editBerita($id) 
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Edit Berita',
            'validation' => \Config\Services::validation(),
            'brt' => $this->beritaModel->getBerita($id)
        ];
        return view('admin/berita/editBerita', $data);
    }
    public function updateBerita($id)
    {
        // ccek validasi input
        if(!$this->validate([
            'txtTitle' => [
                'rules' => 'required[infosklh.title_info,{txtId}]',
                'errors' => [
                    'required' => 'Title Berita Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Title already exist!'
                ]
            ],
            'txtLink' => [
                // 'rules' => 'required[infosklh.link_info,{txtId}]',
                // 'errors' => [
                    // 'required' => 'Link Berita Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Link already exist!'
                // ]
            ],
            'txtIsi' => [
                'rules' => 'required|is_unique[infosklh.isi_info,{txtId}]',
                'errors' => [
                    'required' => 'Isi Berita Tidak Boleh Kosong!',
                    'is_unique' => 'Isi Berita Tidak Boleh Sama!'
                ]
            ]
        ])) {
            return redirect()->to('/admin/editBerita/' . $this->request->getVar('txtId'))->withInput();
        }

        $this->beritaModel->save([
            'id_info' => $id,
            'title_info' => $this->request->getVar('txtTitle'),
            'link_info' => $this->request->getVar('txtLink'),
            'isi_info' => $this->request->getVar('txtIsi')
            // 'gambar_info' => $namaGambar
        ]);

        session()->setFlashdata('pesan', 'Berita Telah Diupdate!');
        return redirect()->to('/admin/berita');
    }

    // GALERI ~ GALERI
    public function galeri()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $galeri = $this->db->table('galeri');
        $query = $galeri->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Galeri',
            'galeri' => $query
        ];
        // return view('welcome_message');
        return view('admin/galeri/galeri', $data);
    }
    public function addGaleri()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Tambah Galeri',
            'validation' => \Config\Services::validation()
        ];
        return view('admin/galeri/addGaleri', $data);
    }
    public function saveGaleri() 
    {
        // ccek validasi input
        if(!$this->validate([
            'txtTitle' => [
                'rules' => 'required[galeri.title_galeri]',
                'errors' => [
                    'required' => 'Title Gambar Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Title already exist!'
                ]
            ],
            'txtIsi' => [
                'rules' => 'required[galeri.desc_galeri]',
                'errors' => [
                    'required' => 'Deskripsi Gambar Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Isi already exist!'
                ]
            ],
            'txtGambar' => [
                'rules' => 'max_size[txtGambar,1600]|is_image[txtGambar]|mime_in[txtGambar,image/jpg,image/jpeg,image/png]',
                'errors' => [
                    'max_size' => 'Ukuran gambar terlalu besar',
                    'is_image' => 'Hanya Gambar Yang Diperbolehkan!',
                    'mime_in' => 'Hanya Gambar Yang Diperbolehkan!'
                ]
            ]
        ])) {
            return redirect()->to('/admin/addGaleri')->withInput();
        }
        
        // ambil gambar
        $fileGambar = $this->request->getFile('txtGambar');
        // cek ada gambar atau tidak
        if($fileGambar->getError() == 4) {
            $namaGambar = 'no-image.png';
        } else {
        // generate nama foto
        $namaGambar = $fileGambar->getRandomName();
        // pindah file
        $fileGambar->move('img', $namaGambar);
        }

        $this->galeriModel->save([
            'title_galeri' => $this->request->getVar('txtTitle'),
            'desc_galeri' => $this->request->getVar('txtIsi'),
            'gambar_galeri' => $namaGambar
        ]);

        session()->setFlashdata('pesan', 'Foto Baru Telah Ditambahkan!');
        return redirect()->to('/admin/galeri');
    }
    public function deleteGaleri($id)
    {
        $galeri = $this->galeriModel->find($id);

        // cek gambar default
        if($galeri['gambar_galeri'] != 'no-image.png') {
            // hapus gambar
            unlink('img/' . $galeri['gambar_galeri']);
        }

        $this->galeriModel->delete($id);
        session()->setFlashdata('pesan', 'Foto Lama Telah Terhapus!');
        return redirect()->to('/admin/galeri');
    }
    public function editGaleri($id)
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Edit Galeri',
            'validation' => \Config\Services::validation(),
            'glr' => $this->galeriModel->getGaleri($id)
        ];
        return view('admin/galeri/editGaleri', $data);
    }
    public function updateGaleri($id)
    {
        // ccek validasi input
        if(!$this->validate([
            'txtTitle' => [
                'rules' => 'required[galeri.title_galeri]',
                'errors' => [
                    'required' => 'Project Title cannot be empty!',
                    // 'is_unique' => 'Project Title already exist!'
                ]
            ],
            'txtIsi' => [
                'rules' => 'required[galeri.desc_galeri]',
                'errors' => [
                    'required' => 'Project Isi cannot be empty!',
                    // 'is_unique' => 'Project Isi already exist!'
                ]
            ],
            'txtGambar' => [
                'rules' => 'max_size[txtGambar,1600]|is_image[txtGambar]|mime_in[txtGambar,image/jpg,image/jpeg,image/png]',
                'errors' => [
                    'max_size' => 'Ukuran gambar terlalu besar',
                    'is_image' => 'Hanya Gambar Yang Diperbolehkan!',
                    'mime_in' => 'Hanya Gambar Yang Diperbolehkan!'
                ]
            ]
        ])) {
            return redirect()->to('/admin/galeri/editGaleri/' . $this->request->getVar('txtId'))->withInput();
        }

        $dataUpdate = [
            'id_galeri' => $id,
            'title_galeri' => $this->request->getVar('txtTitle'),
            'desc_galeri' => $this->request->getVar('txtIsi'),
            // 'gambar_galeri' => $namaGambar
        ];

            // ambil gambar
            $fileGambar = $this->request->getFile('txtGambar');
            // cek ada gambar atau tidak
            if($fileGambar != '') {
                $namaGambar = $fileGambar->getRandomName();
                $dataUpdate['gambar_galeri'] = $namaGambar;
                if($this->request->getVar('txtGambarLama') != 'download.png') {
                    # melihat data yang lama di database dan menghapusnya jika ada
                    $galeri = $this->galeriModel->find($id);
                    if (file_exists(ROOTPATH . 'public/img/' . $galeri['gambar_galeri'])) {
                        unlink(ROOTPATH . 'public/img/' . $galeri['gambar_galeri']);
                    }
                    $fileGambar->move(ROOTPATH . 'public/img', $namaGambar);
                } else {
                    // pindah file
                    $fileGambar->move(ROOTPATH . 'public/img', $namaGambar);
                }
            }

        $this->galeriModel->save($dataUpdate);

        session()->setFlashdata('pesan', 'Foto Lama Telah Diedit!');
        return redirect()->to('/admin/galeri');
    }

    // JADWAL ~ JADWAL
    public function jadwal()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $jgmeet = $this->db->table('jgmeet');
        $queryGmeet = $jgmeet->get()->getResultArray();
        
        $jtugas = $this->db->table('jtugas');
        $queryTugas = $jtugas->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Jadwal',
            'jvideo' => $queryGmeet,
            'jtugas' => $queryTugas
        ];
        // return view('welcome_message');
        return view('admin/jadwal/jadwal', $data);
    }

    public function editJgmeet($id)
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Edit Jadwal',
            'validation' => \Config\Services::validation(),
            'jgm' => $this->jgmeetModel->getJgmeet($id)
        ];
        return view('admin/jadwal/editJgmeet', $data);
    }
    public function updateJgmeet($id)
    {
        // ccek validasi input
        if(!$this->validate([
            'txtHari' => [
                'rules' => 'required[jgmeet.hari_jgmeet,{txtId}]',
                'errors' => [
                    'required' => 'Hari Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Title already exist!'
                ]
            ],
            'txtSeragam' => [
                'rules' => 'required[jgmeet.seragam_jgmeet,{txtId}]',
                'errors' => [
                    'required' => 'Seragam Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Link already exist!'
                ]
            ],
            'txtMapel1' => [
                'rules' => 'required[jgmeet.mapel1_jgmeet,{txtId}]',
                'errors' => [
                    'required' => 'Mapel 1 Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Isi already exist!'
                ]
            ],
            'txtNmguru1' => [
                'rules' => 'required[jgmeet.nmguru1_jgmeet,{txtid}]',
                'errors' => [
                    'required' => 'Nama Guru Mapel 1 Tidak Boleh Kosong!'
                ]
            ],
            'txtMapel2' => [
                'rules' => 'required[jgmeet.mapel2_jgmeet,{txtId}]',
                'errors' => [
                    'required' => 'Mapel 2 Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Isi already exist!'
                ]
            ],
            'txtNmguru2' => [
                'rules' => 'required[jgmeet.nmguru2_jgmeet,{txtid}]',
                'errors' => [
                    'required' => 'Nama Guru Mapel 2 Tidak Boleh Kosong!'
                ]
            ],
            'txtMapel3' => [
                'rules' => 'required[jgmeet.mapel3_jgmeet,{txtId}]',
                'errors' => [
                    'required' => 'Mapel 3 Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Isi already exist!'
                ]
            ],
            'txtNmguru3' => [
                'rules' => 'required[jgmeet.nmguru3_jgmeet,{txtid}]',
                'errors' => [
                    'required' => 'Nama Guru Mapel 3 Tidak Boleh Kosong!'
                ]
            ]
        ])) {
            return redirect()->to('/admin/jadwal/editJgmeet/' . $this->request->getVar('txtId'))->withInput();
        }

        $this->jgmeetModel->save([
            'id_jgmeet' => $id,
            'hari_jgmeet' => $this->request->getVar('txtHari'),
            'seragam_jgmeet' => $this->request->getVar('txtSeragam'),
            'mapel1_jgmeet' => $this->request->getVar('txtMapel1'),
            'nmguru1_jgmeet' => $this->request->getVar('txtNmguru1'),
            'mapel2_jgmeet' => $this->request->getVar('txtMapel2'),
            'nmguru2_jgmeet' => $this->request->getVar('txtNmguru2'),
            'mapel3_jgmeet' => $this->request->getVar('txtMapel3'),
            'nmguru3_jgmeet' => $this->request->getVar('txtNmguru3'),
            'mapel4_jgmeet' => $this->request->getVar('txtMapel4'),
            'nmguru4_jgmeet' => $this->request->getVar('txtNmguru4'),
            // 'gambar_info' => $namaGambar
        ]);

        session()->setFlashdata('pesan-jgmeet', 'Jadwal Video Conference Telah Diupdate!');
        return redirect()->to('/admin/jadwal#jadwal-video');
    }

    public function editJtugas($id)
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Edit Jadwal',
            'validation' => \Config\Services::validation(),
            'jgt' => $this->jtugasModel->getJtugas($id)
        ];
        return view('admin/jadwal/editJtugas', $data);
    }
    public function updateJtugas($id)
    {
        // ccek validasi input
        if(!$this->validate([
            'txtHari' => [
                'rules' => 'required[jtugas.hari_jtugas,{txtId}]',
                'errors' => [
                    'required' => 'Hari Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Title already exist!'
                ]
            ],
            'txtMapel1' => [
                'rules' => 'required[jtugas.mapel1_jtugas,{txtId}]',
                'errors' => [
                    'required' => 'Mapel 1 Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Isi already exist!'
                ]
            ],
            'txtNmguru1' => [
                'rules' => 'required[jgmeet.nmguru1_jtugas,{txtid}]',
                'errors' => [
                    'required' => 'Nama Guru Mapel 1 Tidak Boleh Kosong!'
                ]
            ],
            'txtMapel2' => [
                'rules' => 'required[jtugas.mapel2_jtugas,{txtId}]',
                'errors' => [
                    'required' => 'Mapel 2 Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Isi already exist!'
                ]
            ],
            'txtNmguru2' => [
                'rules' => 'required[jgmeet.nmguru2_jtugas,{txtid}]',
                'errors' => [
                    'required' => 'Nama Guru Mapel 2 Tidak Boleh Kosong!'
                ]
            ],
            'txtMapel3' => [
                'rules' => 'required[jtugas.mapel3_jtugas,{txtId}]',
                'errors' => [
                    'required' => 'Mapel 3 Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Isi already exist!'
                ]
            ],
            'txtNmguru3' => [
                'rules' => 'required[jgmeet.nmguru3_jtugas,{txtid}]',
                'errors' => [
                    'required' => 'Nama Guru Mapel 3 Tidak Boleh Kosong!'
                ]
            ],
            // 'txtMapel4' => [
            //     'rules' => 'required[jtugas.mapel4_jtugas,{txtId}]',
            //     'errors' => [
            //         // 'required' => 'Mapel 4 Tidak Boleh Kosong!',
            //         // 'is_unique' => 'Project Isi already exist!'
            //     ]
            // ],
            // 'txtNmguru4' => [
            //     'rules' => 'required[jgmeet.nmguru4_jtugas,{txtid}]',
            //     'errors' => [
            //         // 'required' => 'Nama Guru Mapel 4 Tidak Boleh Kosong!'
            //     ]
            // ]
        ])) {
            return redirect()->to('/admin/editJtugas/' . $this->request->getVar('txtId'))->withInput();
        }

        $this->jtugasModel->save([
            'id_jtugas' => $id,
            'hari_jtugas' => $this->request->getVar('txtHari'),
            'mapel1_jtugas' => $this->request->getVar('txtMapel1'),
            'nmguru1_jtugas' => $this->request->getVar('txtNmguru1'),
            'mapel2_jtugas' => $this->request->getVar('txtMapel2'),
            'nmguru2_jtugas' => $this->request->getVar('txtNmguru2'),
            'mapel3_jtugas' => $this->request->getVar('txtMapel3'),
            'nmguru3_jtugas' => $this->request->getVar('txtNmguru3'),
            'mapel4_jtugas' => $this->request->getVar('txtMapel4'),
            'nmguru4_jtugas' => $this->request->getVar('txtNmguru4'),
            // 'gambar_info' => $namaGambar
        ]);

        session()->setFlashdata('pesan-jtugas', 'Jadwal Pemberian Tugas Telah Diupdate!');
        return redirect()->to('/admin/jadwal#jadwal-penugasan');
    }

    // SISWA ~ SISWA
    public function siswa()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $absen = $this->db->table('siswa');// $this->db mengambil dari property $db
        $absen->orderBy('absen_siswa', 'ASC');
        
        $keyword = $this->request->getVar('keyword');
        if($keyword) {
            $siswa = $this->siswaModel->search($keyword);
        } else {
            $siswa = $this->siswaModel;
        }

        $query = $siswa->orderBy('absen_siswa', 'ASC')->get()->getResultArray();

        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Data Siswa',
            'siswa' => $query
        ];
        // return view('welcome_message');
        return view('admin/siswa/siswa', $data);
    }

    public function addSiswa()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Tambah Siswa',
            'validation' => \Config\Services::validation(),
        ];
        return view('admin/siswa/addSiswa', $data);
    }

    public function saveSiswa()
    {
        // ccek validasi input
        if(!$this->validate([
            'txtAbsen' => [
                'rules' => 'required|is_unique[siswa.absen_siswa]',
                'errors' => [
                    'required' => 'Nomor Absen Siswa Tidak Boleh Kosong!',
                    'is_unique' => 'Nomor Absen Siswa Tidak Boleh Sama!'
                ]
            ],
            'txtNamSis' => [
                'rules' => 'required|is_unique[siswa.nama_siswa]',
                'errors' => [
                    'required' => 'Nama Siswa Tidak Boleh Kosong!',
                    'is_unique' => 'Nama Siswa Tidak Boleh Sama!'
                ]
            ],
            // 'txtDeskSis' => [
                // 'rules' => 'required',
                // 'errors' => [
                    // 'required' => 'Deskripsi Siswa Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Isi already exist!'
                // ]
            // ],
            'txtIg' => [
                'rules' => 'is_unique[siswa.ins_siswa]',
                'errors' => [
                    // 'required' => 'Username Instagram Siswa Tidak Boleh Kosong!',
                    'is_unique' => 'Username Instagram Siswa Tidak Boleh Sama!'
                ]
            ],
            'txtGambar' => [
                'rules' => 'max_size[txtGambar,1600]|is_image[txtGambar]|mime_in[txtGambar,image/jpg,image/jpeg,image/png]',
                'errors' => [
                    'max_size' => 'Ukuran gambar terlalu besar',
                    'is_image' => 'Hanya Gambar Yang Diperbolehkan!',
                    'mime_in' => 'Hanya Gambar Yang Diperbolehkan!'
                ]
            ]
        ])) {
            return redirect()->to('/admin/addSiswa')->withInput();
        }
        
        // ambil gambar
        $fileGambar = $this->request->getFile('txtGambar');
        // cek ada gambar atau tidak
        if($fileGambar->getError() == 4) {
            $namaGambar = 'download.png';
        } else {
        // generate nama foto
        $namaGambar = $fileGambar->getName();
        // pindah file
        $fileGambar->move('img', $namaGambar);
        }

        $this->siswaModel->save([
            'absen_siswa' => $this->request->getVar('txtAbsen'),
            'nama_siswa' => $this->request->getVar('txtNamSis'),
            'desk_siswa' => $this->request->getVar('txtDeskSis'),
            'ins_siswa' => $this->request->getVar('txtIg'),
            'foto_siswa' => $namaGambar
        ]);

        session()->setFlashdata('pesan', 'Siswa Baru Telah Ditambah!');
        return redirect()->to('/admin/siswa');
    }

    public function editSiswa($id)
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Edit Siswa',
            'validation' => \Config\Services::validation(),
            'sis' => $this->siswaModel->getSiswa($id)
        ];
        return view('/admin/siswa/editSiswa', $data);
    }
    public function updateSiswa($id)
    {
        // ccek validasi input
        if(!$this->validate([
            'txtAbsen' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Nomor Absen Siswa Tidak Boleh Kosong!',
                    // 'is_unique' => 'Nomor Absen Siswa Tidak Boleh Sama!'
                ]
            ],
            'txtNamSis' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Nama Siswa Tidak Boleh Kosong!',
                    // 'is_unique' => 'Nama Siswa Tidak Boleh Sama!'
                ]
            ],
            // 'txtDeskSis' => [
                // 'rules' => 'required',
                // 'errors' => [
                    // 'required' => 'Deskripsi Siswa Tidak Boleh Kosong!',
                    // 'is_unique' => 'Project Isi already exist!'
                // ]
            // ],
            // 'txtIg' => [
                // 'rules' => 'is_unique[siswa.ins_siswa]',
                // 'errors' => [
                    // 'required' => 'Username Instagram Siswa Tidak Boleh Kosong!',
                    // 'is_unique' => 'Username Instagram Siswa Tidak Boleh Sama!'
                // ]
            // ],
            'txtGambar' => [
                'rules' => 'max_size[txtGambar,1600]|is_image[txtGambar]|mime_in[txtGambar,image/jpg,image/jpeg,image/png]',
                'errors' => [
                    'max_size' => 'Ukuran gambar terlalu besar',
                    'is_image' => 'Hanya Gambar Yang Diperbolehkan!',
                    'mime_in' => 'Hanya Gambar Yang Diperbolehkan!'
                ]
            ]
        ])) {
            return redirect()->to('/admin/editSiswa/' . $this->request->getVar('txtId'))->withInput();
        }
        
        // ambil gambar
        // $fileGambar = $this->request->getFile('txtGambar');
        // cek ada gambar atau tidak
        // $namaGambar = $fileGambar->getName();
        // if($fileGambar != '') {
        //     if($this->request->getVar('txtGambarLama') != 'download.png') {

        //         $fileGambar->move(ROOTPATH . 'public/img', $namaGambar);

        //     } else {
        //         pindah file
        //         $fileGambar->move(ROOTPATH . 'public/img', $namaGambar);
        //     }
        // }

        // $this->siswaModel->save([
        //     'id_siswa' => $id,
        //     'absen_siswa' => $this->request->getVar('txtAbsen'),
        //     'nama_siswa' => $this->request->getVar('txtNamSis'),
        //     'desk_siswa' => $this->request->getVar('txtDeskSis'),
        //     'ins_siswa' => $this->request->getVar('txtIg'),
        //     'foto_siswa' => $namaGambar
        // ]);

        $dataUpdate = [
            'id_siswa' => $id,
            'absen_siswa' => $this->request->getVar('txtAbsen'),
            'nama_siswa' => $this->request->getVar('txtNamSis'),
            'desk_siswa' => $this->request->getVar('txtDeskSis'),
            'ins_siswa' => $this->request->getVar('txtIg'),
        ];

        // ambil gambar
        $fileGambar = $this->request->getFile('txtGambar');
        // cek ada gambar atau tidak
        if($fileGambar != '') {
            $namaGambar = $fileGambar->getName();
            $dataUpdate['foto_siswa'] = $namaGambar;
            if($this->request->getVar('txtGambarLama') != 'download.png') {
                # melihat data yang lama di database dan menghapusnya jika ada
                $siswa = $this->siswaModel->find($id);
                if (file_exists(ROOTPATH . 'public/img/' . $siswa['foto_siswa'])) {
                    unlink(ROOTPATH . 'public/img/' . $siswa['foto_siswa']);
                }
                $fileGambar->move(ROOTPATH . 'public/img', $namaGambar);
            } else {
                // pindah file
                $fileGambar->move(ROOTPATH . 'public/img', $namaGambar);
            }
        }

        $this->siswaModel->save($dataUpdate);

        session()->setFlashdata('pesan', 'Siswa Baru Telah Ditambah!');
        return redirect()->to('/admin/siswa');
    }

    public function deleteSiswa($id)
    {
        $siswa = $this->siswaModel->find($id);

        // cek gambar default
        if($siswa['foto_siswa'] != 'download.png') {
            // hapus gambar
            unlink('img/' . $siswa['foto_siswa']);
        }

        $this->siswaModel->delete($id);
        session()->setFlashdata('pesan', 'Siswa Lama Telah Terhapus!');
        return redirect()->to('/admin/siswa');
    }

    // CONTACT ~ CONTACT
    public function contact()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Contact'
        ];
        // return view('welcome_message');
        return view('admin/contact', $data);
    }
}
