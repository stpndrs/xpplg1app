<?php

namespace App\Controllers;

use App\Models\BeritaModel;

class Berita extends BaseController
{
    protected $beritaModel;
    protected $db;
    public function __construct()
    {
        $this->db = \Config\Database::connect();    
        $this->beritaModel = new BeritaModel();
    }
    $data = 'Here is some text!';
	$name = 'mytext.txt';
	return $response->download($name, $data);
}
