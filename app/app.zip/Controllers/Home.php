<?php

namespace App\Controllers;

// class Home extends BaseController
// {
//     public function index()
//     {
//         return view('welcome_message');
//     }
// }

use App\Models\LayoutModel;
use App\Models\HomeModel;
use App\Models\BeritaModel;
use App\Models\GaleriModel;
class Home extends BaseController
{
    protected $db;
    protected $layoutModel;
    protected $homeModel;
    protected $beritaModel;
    protected $galeriModel;
    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->layoutModel = new LayoutModel();
        $this->homeModel = new HomeModel();    
        $this->beritaModel = new BeritaModel();
        $this->galeriModel = new GaleriModel();
    }
    public function index()
    {
        $layout = $this->db->table('layout');
        $home = $this->db->table('home');
        $berita = $this->db->table('infosklh');
        $galeri = $this->db->table('galeri');
        $queryLayout = $layout->get()->getResultArray();
        $queryHome = $home->get()->getResultArray();
        $queryGaleri = $galeri->get(3)->getResultArray();
        $queryBerita = $berita->get(3)->getResultArray();
        $data = [
            'title' => 'Intelligence Class',
            'layout' => $queryLayout,
            'home' => $queryHome,
            'galeri' => $queryGaleri,
            'berita' => $queryBerita
        ];
        return view('home', $data);
    }
}
