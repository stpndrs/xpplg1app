<?php

namespace App\Controllers;

use App\Models\LayoutModel;
// use App\Models\AbsenModel;

class Absen extends BaseController
{
    protected $layoutModel;
    protected $db;
    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->layoutModel = new LayoutModel();
    }
    public function index()
    {
        $absen = $this->db->table('siswa');// $this->db mengambil dari property $db
        $absen->orderBy('absen_siswa', 'ASC');
        $query = $absen->get()->getResultArray();
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Absen',
            'absen' => $query
        ];
        // return view('welcome_message');
        return view('absen', $data);
    }
}