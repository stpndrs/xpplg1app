<?php

namespace App\Controllers;

use App\Models\LayoutModel;
use App\Models\JgmeetModel;
use App\Models\JtugasModel;

class Jadwal extends BaseController
{
    protected $layoutModel;
    protected $jgmeetModel;
    protected $jtugasModel;
    protected $db;
    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->layoutModel = new LayoutModel();
        $this->jgmeetModel = new JgmeetModel();    
        $this->jtugasModel = new JtugasModel();    
    }
    public function index()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getResultArray();

        $jgmeet = $this->db->table('jgmeet');
        $queryGmeet = $jgmeet->get()->getResultArray();
        
        $jtugas = $this->db->table('jtugas');
        $queryTugas = $jtugas->get()->getResultArray();
        $data = [
            'layout' => $layout,
            'title' => 'Intelligence Class | Jadwal',
            'jvideo' => $queryGmeet,
            'jtugas' => $queryTugas
        ];
        // return view('welcome_message');
        return view('jadwal', $data);
    }
}
