<?php

namespace App\Controllers;

use App\Models\LayoutModel;

class Contact extends BaseController
{
    protected $layoutModel;
    protected $db;
    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->layoutModel = new LayoutModel();
    }
    public function index()
    {
        $configJPas = $this->db->table('configstatus')->where('nama_config', 'Status PAS')->get()->getRowArray();
        $statusPas = $configJPas['value'];

        $configJgmeet = $this->db->table('configstatus')->where('nama_config', 'Status JGMEET')->get()->getRowArray();
        $statusJgmeet = $configJgmeet['value'];

        $configJtugas = $this->db->table('configstatus')->where('nama_config', 'Status JTUGAS')->get()->getRowArray();
        $statusJtugas = $configJtugas['value'];

        $configJpiket = $this->db->table('configstatus')->where('nama_config', 'Status JPiket')->get()->getRowArray();
        $statusJpiket = $configJpiket['value'];

        $configJoffline = $this->db->table('configstatus')->where('nama_config', 'Status JOffline')->get()->getRowArray();
        $statusJoffline = $configJoffline['value'];

        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getRowArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Contact',
            'gtagJS' => '<!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=G-N26R81P5DP"></script>
            <script>
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag(\'js\', new Date());
            
              gtag(\'config\', \'G-N26R81P5DP\');
            </script>',

            'statusPas' => $statusPas,
            'statusJgmeet' => $statusJgmeet,
            'statusJtugas' => $statusJtugas,
            'statusJpiket' => $statusJpiket,
            'statusJoffline' => $statusJoffline,
        ];
        // return view('welcome_message');
        return view('/pages/contact', $data);
    }
}
