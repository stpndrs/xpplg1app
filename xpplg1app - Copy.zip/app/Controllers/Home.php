<?php

namespace App\Controllers;

// class Home extends BaseController
// {
//     public function index()
//     {
//         return view('welcome_message');
//     }
// }

use App\Models\LayoutModel;
use App\Models\HomeModel;
use App\Models\BeritaModel;
use App\Models\PostModel;

class Home extends BaseController
{
    protected $db;
    protected $layoutModel;
    protected $homeModel;
    protected $beritaModel;
    protected $postModel;
    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->layoutModel = new LayoutModel();
        $this->homeModel = new HomeModel();
        $this->beritaModel = new BeritaModel();
        $this->postModel = new PostModel();
    }
    public function index()
    {
        $configJPas = $this->db->table('configstatus')->where('nama_config', 'Status PAS')->get()->getRowArray();
        $statusPas = $configJPas['value'];

        $configJgmeet = $this->db->table('configstatus')->where('nama_config', 'Status JGMEET')->get()->getRowArray();
        $statusJgmeet = $configJgmeet['value'];

        $configJtugas = $this->db->table('configstatus')->where('nama_config', 'Status JTUGAS')->get()->getRowArray();
        $statusJtugas = $configJtugas['value'];

        $configJpiket = $this->db->table('configstatus')->where('nama_config', 'Status JPiket')->get()->getRowArray();
        $statusJpiket = $configJpiket['value'];

        $configJoffline = $this->db->table('configstatus')->where('nama_config', 'Status JOffline')->get()->getRowArray();
        $statusJoffline = $configJoffline['value'];

        $layout = $this->db->table('layout');
        $home = $this->db->table('home');
        $berita = $this->db->table('infosklh');
        $posts = $this->db->table('tb_post')->orderBy('id', 'DESC')->get(3)->getResultArray();
        $queryLayout = $layout->get()->getRowArray();
        $queryHome = $home->get()->getResultArray();
        $postsWithImages = [];
        foreach ($posts as $post) {
            $pictures = $this->db->table('tb_gambar')->where('post_id', $post['id'])->where('gambar !=', 'no-image.png')->get()->getResultArray();
            $post['gambar'] = [];
            foreach ($pictures as $picture) {
                $post['gambar'][] = $picture;
            }
            $postsWithImages[] = $post;
        }
        $queryBerita = $berita->get(3)->getResultArray();
        $data = [
            'title' => 'Intelligence Class',
            'gtagJS' => '<!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=G-N26R81P5DP"></script>
            <script>
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag(\'js\', new Date());
            
              gtag(\'config\', \'G-N26R81P5DP\');
            </script>',
            'layout' => $queryLayout,
            'home' => $queryHome,
            'galeri' => $postsWithImages,
            'berita' => $queryBerita,

            'statusPas' => $statusPas,
            'statusJgmeet' => $statusJgmeet,
            'statusJtugas' => $statusJtugas,
            'statusJpiket' => $statusJpiket,
            'statusJoffline' => $statusJoffline,
        ];
        return view('/pages/home', $data);
    }
}
