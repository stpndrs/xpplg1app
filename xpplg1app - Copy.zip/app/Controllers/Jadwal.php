<?php

namespace App\Controllers;

use App\Models\LayoutModel;
use App\Models\JgmeetModel;
use App\Models\JtugasModel;
use App\Models\JpiketModel;
use App\Models\JpasModel;

class Jadwal extends BaseController
{
    protected $layoutModel;
    protected $jgmeetModel;
    protected $jtugasModel;
    protected $db;
    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->layoutModel = new LayoutModel();
        $this->jgmeetModel = new JgmeetModel();
        $this->jtugasModel = new JtugasModel();
        $this->jpiketModel = new JpiketModel();
        $this->jpasModel = new JpasModel();
    }
    public function JadwalPelajaran()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getRowArray();

        $jgmeet = $this->db->table('jgmeet');
        $queryGmeet = $jgmeet->get()->getResultArray();

        $jtugas = $this->db->table('jtugas');
        $queryTugas = $jtugas->get()->getResultArray();

        $jpiket = $this->db->table('jpiket');
        $queryPiket = $jpiket->get()->getResultArray();

        $joffline = $this->db->table('joffline');
        $queryOffline = $joffline->get()->getResultArray();

        $configJPas = $this->db->table('configstatus')->where('nama_config', 'Status PAS')->get()->getRowArray();
        $statusPas = $configJPas['value'];

        $configJgmeet = $this->db->table('configstatus')->where('nama_config', 'Status JGMEET')->get()->getRowArray();
        $statusJgmeet = $configJgmeet['value'];

        $configJtugas = $this->db->table('configstatus')->where('nama_config', 'Status JTUGAS')->get()->getRowArray();
        $statusJtugas = $configJtugas['value'];

        $configJpiket = $this->db->table('configstatus')->where('nama_config', 'Status JPiket')->get()->getRowArray();
        $statusJpiket = $configJpiket['value'];

        $configJoffline = $this->db->table('configstatus')->where('nama_config', 'Status JOffline')->get()->getRowArray();
        $statusJoffline = $configJoffline['value'];

        $jpas = $this->db->table('jpas');
        $queryPAS = $jpas->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Jadwal',
            'gtagJS' => '<!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=G-N26R81P5DP"></script>
            <script>
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag(\'js\', new Date());
            
              gtag(\'config\', \'G-N26R81P5DP\');
            </script>',
            'jvideo' => $queryGmeet,
            'jtugas' => $queryTugas,
            'jpik' => $queryPiket,
            'jpas' => $queryPAS,
            'joffline' => $queryOffline,
            'statusPas' => $statusPas,
            'statusJgmeet' => $statusJgmeet,
            'statusJtugas' => $statusJtugas,
            'statusJpiket' => $statusJpiket,
            'statusJoffline' => $statusJoffline,
        ];
        // return view('welcome_message');
        return view('/pages/jadwalSkl', $data);
    }
    public function JadwalPiket()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getRowArray();

        $jgmeet = $this->db->table('jgmeet');
        $queryGmeet = $jgmeet->get()->getResultArray();

        $jtugas = $this->db->table('jtugas');
        $queryTugas = $jtugas->get()->getResultArray();

        $jpiket = $this->db->table('jpiket');
        $queryPiket = $jpiket->get()->getResultArray();

        $configJPas = $this->db->table('configstatus')->where('nama_config', 'Status PAS')->get()->getRowArray();
        $statusPas = $configJPas['value'];

        $configJgmeet = $this->db->table('configstatus')->where('nama_config', 'Status JGMEET')->get()->getRowArray();
        $statusJgmeet = $configJgmeet['value'];

        $configJtugas = $this->db->table('configstatus')->where('nama_config', 'Status JTUGAS')->get()->getRowArray();
        $statusJtugas = $configJtugas['value'];

        $configJpiket = $this->db->table('configstatus')->where('nama_config', 'Status JPiket')->get()->getRowArray();
        $statusJpiket = $configJpiket['value'];

        $configJoffline = $this->db->table('configstatus')->where('nama_config', 'Status JOffline')->get()->getRowArray();
        $statusJoffline = $configJoffline['value'];

        $jpas = $this->db->table('jpas');
        $queryPAS = $jpas->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Jadwal Piket',
            'jvideo' => $queryGmeet,
            'jtugas' => $queryTugas,
            'jpik' => $queryPiket,
            'jpas' => $queryPAS,
            'statusPas' => $statusPas,
            'statusJgmeet' => $statusJgmeet,
            'statusJtugas' => $statusJtugas,
            'statusJpiket' => $statusJpiket,
            'statusJoffline' => $statusJoffline,

            'gtagJS' => '<!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=G-N26R81P5DP"></script>
            <script>
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag(\'js\', new Date());
            
              gtag(\'config\', \'G-N26R81P5DP\');
            </script>',
        ];
        // return view('welcome_message');
        return view('/pages/jadwalPiket', $data);
    }
    public function JadwalUjian()
    {
        $layout = $this->db->table('layout');
        $queryLayout = $layout->get()->getRowArray();

        $jgmeet = $this->db->table('jgmeet');
        $queryGmeet = $jgmeet->get()->getResultArray();

        $jtugas = $this->db->table('jtugas');
        $queryTugas = $jtugas->get()->getResultArray();

        $jpiket = $this->db->table('jpiket');
        $queryPiket = $jpiket->get()->getResultArray();

        $configJPas = $this->db->table('configstatus')->where('nama_config', 'Status PAS')->get()->getRowArray();
        $statusPas = $configJPas['value'];

        $configJgmeet = $this->db->table('configstatus')->where('nama_config', 'Status JGMEET')->get()->getRowArray();
        $statusJgmeet = $configJgmeet['value'];

        $configJtugas = $this->db->table('configstatus')->where('nama_config', 'Status JTUGAS')->get()->getRowArray();
        $statusJtugas = $configJtugas['value'];

        $configJpiket = $this->db->table('configstatus')->where('nama_config', 'Status JPiket')->get()->getRowArray();
        $statusJpiket = $configJpiket['value'];

        $configJoffline = $this->db->table('configstatus')->where('nama_config', 'Status JOffline')->get()->getRowArray();
        $statusJoffline = $configJoffline['value'];

        $jpas = $this->db->table('jpas');
        $queryPAS = $jpas->get()->getResultArray();
        $data = [
            'layout' => $queryLayout,
            'title' => 'Intelligence Class | Jadwal Ujian',
            'jvideo' => $queryGmeet,
            'jtugas' => $queryTugas,
            'jpik' => $queryPiket,
            'jpas' => $queryPAS,
            'statusPas' => $statusPas,
            'statusJgmeet' => $statusJgmeet,
            'statusJtugas' => $statusJtugas,
            'statusJpiket' => $statusJpiket,
            'statusJoffline' => $statusJoffline,

            'gtagJS' => '<!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=G-N26R81P5DP"></script>
            <script>
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag(\'js\', new Date());
            
              gtag(\'config\', \'G-N26R81P5DP\');
            </script>',
        ];
        // return view('welcome_message');
        return view('/pages/jadwalPas', $data);
    }
}
