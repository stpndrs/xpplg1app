<footer>
    <div class="container">
        <div class="row">

            <div class="col-lg">
                <h4 class="yellow">Intelligence Class</h3>
                <p><a href="#" class="blue">(0541) XXXXXXX</a></p>
                <p><a href="#" class="blue">emailsekolah@gmail.com</a></p>
                <p><a href="#" class="blue">/</a></p>
            </div>

            <div class="col-lg">
                <h4 class="yellow">Tentang Kami</h3>
                <p><a href="#" class="blue">Sejarah</a></p>
                <p><a href="#" class="blue">Visi & Misi</a></p>
                <p><a href="#" class="blue">Struktur Organisasi</a></p>
            </div>

            <div class="col-lg">
                <h4 class="yellow">Berita Terbaru</h3>
                <p><a href="#" class="blue">Lorem ipsum dolor sit.</a></p>
                <p><a href="#" class="blue">Lorem ipsum dolor sit.</a></p>
                <p><a href="#" class="blue">Lorem ipsum dolor sit.</a></p>
            </div>

            <div class="col-lg">
                <h4 class="yellow"><a class="yellow" href="https://goo.gl/maps/ceFQvdRgC3WDzry36"><i class="bi bi-geo-alt-fill"></i> Samarinda, Kalimantan Timur, Indonesia</a></h3>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d255338.26932911764!2d117.03544149105888!3d-0.509684476647699!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2df5d57d33074935%3A0xef64e9b06c7ad3e7!2sKota%20Samarinda%2C%20Kalimantan%20Timur!5e0!3m2!1sid!2sid!4v1636116267903!5m2!1sid!2sid" width="350" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>

        </div>
    </div>
</footer>