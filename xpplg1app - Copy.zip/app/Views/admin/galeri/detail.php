<?= $this->extend('admin/layout/template'); ?>

<?= $this->section('content'); ?>

.container

<?= $this->endSection(); ?>