<?= $this->extend('/pages/layout/template'); ?>

<?= $this->section('content'); ?>

<div class="container">
    
</div>

<?= $this->endSection(); ?>